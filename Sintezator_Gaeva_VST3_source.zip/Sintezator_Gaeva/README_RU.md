# СИНТЕЗАТОР ГАЕВА — VST3 source project

Проект-заготовка синтезатора для Windows и FL Studio. Это самостоятельный инструмент,
вдохновлённый общими приёмами аналогового и FM-синтеза; он не является копией
проприетарного оборудования или программ Aphex Twin.

## Возможности текущей версии
- 12 голосов полифонии
- два осциллятора с несколькими формами волны
- FM amount и detune
- субосциллятор и шум
- low-pass фильтр с резонансом
- ADSR-подобная огибающая
- drive и reverb
- MIDI input и сохранение параметров плагина

## Сборка на Windows
Нужно установить:
1. Visual Studio 2022 с workload "Desktop development with C++".
2. CMake 3.22 или новее.
3. Git.
4. Интернет при первой сборке: CMake скачает JUCE 8.0.6.

Откройте PowerShell в папке проекта и выполните:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

После успешной сборки VST3 обычно находится здесь:

`build/SintezatorGaeva_artefacts/Release/VST3/Синтезатор Гаева.vst3`

Скопируйте папку `.vst3` в стандартную папку VST3:

`C:\Program Files\Common Files\VST3`

Затем в FL Studio откройте Plugin Manager и выполните поиск новых плагинов.

## Важно
Это исходный проект, а не уже собранный и протестированный бинарный VST3.
Сначала соберите его на Windows. При ошибках пришлите полный текст ошибки и
версию CMake/Visual Studio — по ней можно исправить проект.
