#include "PluginProcessor.h"
#include "PluginEditor.h"

static juce::String paramID(const char* s) { return juce::String(s); }

juce::AudioProcessorValueTreeState::ParameterLayout
SintezatorGaevaAudioProcessor::createParameterLayout()
{
    using APF = juce::AudioParameterFloat;
    using APR = juce::AudioParameterInt;
    juce::AudioProcessorValueTreeState::ParameterLayout p;
    p.add(std::make_unique<APR>("wave", "Wave", 0, 3, 0));
    p.add(std::make_unique<APF>("cutoff", "Filter Cutoff", juce::NormalisableRange<float>(40.0f, 18000.0f, 1.0f, 0.35f), 6500.0f));
    p.add(std::make_unique<APF>("res", "Resonance", 0.1f, 1.0f, 0.2f));
    p.add(std::make_unique<APF>("attack", "Attack", 0.001f, 2.0f, 0.01f));
    p.add(std::make_unique<APF>("decay", "Decay", 0.01f, 3.0f, 0.35f));
    p.add(std::make_unique<APF>("sustain", "Sustain", 0.0f, 1.0f, 0.65f));
    p.add(std::make_unique<APF>("release", "Release", 0.01f, 5.0f, 0.45f));
    p.add(std::make_unique<APF>("fm", "FM Amount", 0.0f, 12.0f, 0.0f));
    p.add(std::make_unique<APF>("detune", "Detune", -30.0f, 30.0f, 7.0f));
    p.add(std::make_unique<APF>("sub", "Sub Level", 0.0f, 1.0f, 0.25f));
    p.add(std::make_unique<APF>("noise", "Noise", 0.0f, 0.5f, 0.0f));
    p.add(std::make_unique<APF>("drive", "Drive", 0.0f, 1.0f, 0.08f));
    p.add(std::make_unique<APF>("reverb", "Reverb", 0.0f, 1.0f, 0.18f));
    p.add(std::make_unique<APF>("level", "Output", 0.0f, 1.0f, 0.7f));
    return p;
}

SintezatorGaevaAudioProcessor::SintezatorGaevaAudioProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

void SintezatorGaevaAudioProcessor::prepareToPlay(double sampleRate, int)
{
    sr = sampleRate;
    juce::dsp::ProcessSpec spec { sampleRate, 512, (juce::uint32)getTotalNumOutputChannels() };
    for (auto& v : voices)
    {
        v.filter.prepare(spec);
        v.filter.setType(juce::dsp::StateVariableTPTFilterType::lowpass);
        v.filter.reset();
    }
    juce::dsp::Reverb::Parameters rp;
    rp.roomSize = 0.72f; rp.damping = 0.45f; rp.wetLevel = 0.18f;
    rp.dryLevel = 0.82f; rp.width = 1.0f;
    reverb.setParameters(rp);
    reverb.reset();
}

void SintezatorGaevaAudioProcessor::noteOn(int note, float velocity)
{
    auto* v = &voices[0];
    for (auto& candidate : voices)
        if (!candidate.active) { v = &candidate; break; }
    v->active = true; v->note = note; v->velocity = velocity;
    v->phaseA = v->phaseB = v->phaseSub = 0.0;
    v->env = 0.0f; v->releasing = false;
    v->filter.reset();
}

void SintezatorGaevaAudioProcessor::noteOff(int note)
{
    for (auto& v : voices)
        if (v.active && v.note == note) v.releasing = true;
}

float SintezatorGaevaAudioProcessor::oscillator(double& phase, double frequency, int shape, float pw)
{
    const float p = (float)phase;
    float out = 0.0f;
    if (shape == 0) out = std::sin(juce::MathConstants<float>::twoPi * p);
    else if (shape == 1) out = p < pw ? 1.0f : -1.0f;
    else if (shape == 2) out = 2.0f * p - 1.0f;
    else out = 1.0f - 4.0f * std::abs(p - 0.5f);
    phase += frequency / sr;
    phase -= std::floor(phase);
    return out;
}

void SintezatorGaevaAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();
    const int n = buffer.getNumSamples();
    const int wave = (int)parameters.getRawParameterValue("wave")->load();
    const float cutoff = parameters.getRawParameterValue("cutoff")->load();
    const float resonance = parameters.getRawParameterValue("res")->load();
    const float attack = parameters.getRawParameterValue("attack")->load();
    const float decay = parameters.getRawParameterValue("decay")->load();
    const float sustain = parameters.getRawParameterValue("sustain")->load();
    const float release = parameters.getRawParameterValue("release")->load();
    const float fm = parameters.getRawParameterValue("fm")->load();
    const float detune = parameters.getRawParameterValue("detune")->load();
    const float sub = parameters.getRawParameterValue("sub")->load();
    const float noiseAmt = parameters.getRawParameterValue("noise")->load();
    const float drive = parameters.getRawParameterValue("drive")->load();
    const float level = parameters.getRawParameterValue("level")->load();

    int eventSample = 0;
    for (const auto metadata : midi)
    {
        const auto msg = metadata.getMessage();
        eventSample = juce::jlimit(0, n, metadata.samplePosition);
        if (msg.isNoteOn()) noteOn(msg.getNoteNumber(), msg.getFloatVelocity());
        else if (msg.isNoteOff()) noteOff(msg.getNoteNumber());
    }

    for (int i = 0; i < n; ++i)
    {
        float mix = 0.0f;
        for (auto& v : voices)
        {
            if (!v.active) continue;
            const float target = v.releasing ? 0.0f : sustain;
            if (!v.releasing && v.env < 1.0f)
                v.env += (float)(1.0 / (std::max(0.001f, attack) * (float)sr));
            else if (!v.releasing && v.env > sustain)
                v.env -= (float)(1.0 / (std::max(0.01f, decay) * (float)sr));
            if (v.releasing)
                v.env -= (float)(1.0 / (std::max(0.01f, release) * (float)sr));
            v.env = juce::jlimit(0.0f, 1.0f, v.env);
            if (v.releasing && v.env <= 0.0001f) { v.active = false; continue; }

            const double base = juce::MidiMessage::getMidiNoteInHertz(v.note);
            const float mod = oscillator(v.phaseB, base * 2.0, 0, 0.5f) * fm;
            float a = oscillator(v.phaseA, base, wave, 0.5f);
            float b = oscillator(v.phaseB, base * std::pow(2.0, detune / 1200.0) * (1.0 + mod * 0.01), (wave + 1) % 4, 0.5f);
            float s = oscillator(v.phaseSub, base * 0.5, 1, 0.5f);
            float sample = (a * 0.48f + b * 0.34f + s * sub * 0.35f);
            sample += (random.nextFloat() * 2.0f - 1.0f) * noiseAmt;
            v.filter.setCutoffFrequency(juce::jlimit(20.0f, 20000.0f, cutoff));
            v.filter.setResonance(resonance);
            sample = v.filter.processSample(0, sample);
            sample = std::tanh(sample * (1.0f + drive * 18.0f));
            mix += sample * v.env * v.velocity;
        }
        mix *= level * 0.18f;
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
            buffer.setSample(ch, i, mix);
    }

    juce::dsp::Reverb::Parameters rp;
    rp.roomSize = 0.78f; rp.damping = 0.38f;
    rp.wetLevel = parameters.getRawParameterValue("reverb")->load() * 0.45f;
    rp.dryLevel = 1.0f - rp.wetLevel * 0.5f; rp.width = 1.0f;
    reverb.setParameters(rp);
    if (buffer.getNumChannels() >= 2)
        reverb.processStereo(buffer.getWritePointer(0), buffer.getWritePointer(1), n);
}

juce::AudioProcessorEditor* SintezatorGaevaAudioProcessor::createEditor()
{
    return new SintezatorGaevaAudioProcessorEditor(*this);
}

void SintezatorGaevaAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, dest);
}

void SintezatorGaevaAudioProcessor::setStateInformation(const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, size));
    if (xml && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new SintezatorGaevaAudioProcessor();
}
