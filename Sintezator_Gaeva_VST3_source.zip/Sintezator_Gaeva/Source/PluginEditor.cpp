#include "PluginEditor.h"

SintezatorGaevaAudioProcessorEditor::SintezatorGaevaAudioProcessorEditor(SintezatorGaevaAudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    setSize(760, 470);
    title.setText("СИНТЕЗАТОР ГАЕВА", juce::dontSendNotification);
    title.setFont(juce::Font(juce::FontOptions(25.0f, juce::Font::bold)));
    title.setColour(juce::Label::textColourId, juce::Colour(0xffe7e7ef));
    addAndMakeVisible(title);

    wave.addItem("SINE", 1);
    wave.addItem("SQUARE", 2);
    wave.addItem("SAW", 3);
    wave.addItem("TRIANGLE", 4);
    wave.setSelectedId(1);
    wave.onChange = [this] { audioProcessor.parameters.getParameter("wave")->setValueNotifyingHost((float)(wave.getSelectedId() - 1) / 3.0f); };
    addAndMakeVisible(wave);

    for (size_t i = 0; i < knobs.size(); ++i)
    {
        auto& k = knobs[i];
        k.slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        k.slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 66, 18);
        k.slider.setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffb5f36b));
        k.slider.setColour(juce::Slider::thumbColourId, juce::Colour(0xfff1f1f5));
        k.label.setText(names[i], juce::dontSendNotification);
        k.label.setJustificationType(juce::Justification::centred);
        k.label.setColour(juce::Label::textColourId, juce::Colour(0xffb8bac8));
        addAndMakeVisible(k.slider);
        addAndMakeVisible(k.label);
        k.attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.parameters, ids[i], k.slider);
    }
}

void SintezatorGaevaAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff11121a));
    g.setColour(juce::Colour(0xffb5f36b));
    g.fillRoundedRectangle(22.0f, 78.0f, 716.0f, 2.0f, 1.0f);
    g.setColour(juce::Colour(0xff252735));
    g.drawRoundedRectangle(getLocalBounds().toFloat().reduced(12.0f), 14.0f, 1.0f);
    g.setColour(juce::Colour(0xff777b8e));
    g.setFont(12.0f);
    g.drawText("DUAL OSC  /  FM  /  SUB  /  FILTER  /  DRIVE  /  SPACE", 26, 438, 708, 18, juce::Justification::centred);
}

void SintezatorGaevaAudioProcessorEditor::resized()
{
    title.setBounds(28, 20, 420, 42);
    wave.setBounds(570, 25, 150, 30);
    const int cols = 7;
    const int cellW = 100;
    const int cellH = 155;
    const int startX = 28;
    const int startY = 105;
    for (int i = 0; i < (int)knobs.size(); ++i)
    {
        const int row = i / cols;
        const int col = i % cols;
        auto& k = knobs[(size_t)i];
        k.label.setBounds(startX + col * cellW, startY + row * cellH, 90, 22);
        k.slider.setBounds(startX + col * cellW, startY + row * cellH + 24, 90, 112);
    }
}
