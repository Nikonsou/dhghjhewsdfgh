#pragma once
#include <JuceHeader.h>
#include <array>

class SintezatorGaevaAudioProcessor : public juce::AudioProcessor
{
public:
    SintezatorGaevaAudioProcessor();
    ~SintezatorGaevaAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Синтезатор Гаева"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 2.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    juce::AudioProcessorValueTreeState parameters;

private:
    struct Voice
    {
        bool active = false;
        int note = 60;
        float velocity = 0.0f;
        double phaseA = 0.0, phaseB = 0.0, phaseSub = 0.0;
        float env = 0.0f;
        bool releasing = false;
        juce::dsp::StateVariableTPTFilter<float> filter;
    };

    std::array<Voice, 12> voices;
    double sr = 44100.0;
    juce::Random random;
    juce::dsp::Reverb reverb;

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void noteOn(int note, float velocity);
    void noteOff(int note);
    float oscillator(double& phase, double frequency, int shape, float pw);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SintezatorGaevaAudioProcessor)
};
