#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class SintezatorGaevaAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit SintezatorGaevaAudioProcessorEditor(SintezatorGaevaAudioProcessor&);
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    SintezatorGaevaAudioProcessor& audioProcessor;
    juce::ComboBox wave;
    juce::Label title;
    struct Knob
    {
        juce::Slider slider;
        juce::Label label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
    };
    std::array<Knob, 13> knobs;
    const std::array<const char*, 13> ids {{
        "cutoff","res","attack","decay","sustain","release","fm",
        "detune","sub","noise","drive","reverb","level"
    }};
    const std::array<const char*, 13> names {{
        "CUTOFF","RESONANCE","ATTACK","DECAY","SUSTAIN","RELEASE","FM",
        "DETUNE","SUB","NOISE","DRIVE","REVERB","OUTPUT"
    }};
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SintezatorGaevaAudioProcessorEditor)
};
